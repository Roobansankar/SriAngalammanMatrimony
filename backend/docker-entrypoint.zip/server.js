import cors from "cors";
import "dotenv/config";
import express from "express";
import http from "http";
import morgan from "morgan";
import path from "path";
import { Server as IOServer } from "socket.io";
import { fileURLToPath } from "url";
import db from "./config/db.js";

import adminRoutes from "./routes/admin.js";
import authRoutes from "./routes/auth.js";
import chatRoutes from "./routes/chat.js";
import forgotPasswordRoutes from "./routes/forgotPassword.js";
import galleryRoutes from "./routes/gallery.js";
import interestRoutes from "./routes/interest.js";
import paymentRoutes from "./routes/payment/index.js";
import registerRoutes from "./routes/register.js";
import searchRoutes from "./routes/search.js";
import idSearchRoutes from "./routes/searchByMatriID.js";
import contactRoutes from "./routes/contact.js";

const app = express();
const PORT = process.env.PORT || 5000;
const HOST = "0.0.0.0";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);



const BASE_URL = process.env.BASE_URL;
console.log("BASE_URL:", BASE_URL);


/* DB quick health check */
// `db` is a mysql2 connection pool created in `./config/db.js`.
// Run a single lightweight query at startup and log the result.
db.query("SELECT 1", (err) => {
  if (err) console.error("❌ MySQL pool unreachable at startup:", err);
  else console.log("✅ MySQL pool is reachable");
});

/* Middleware */
app.use(
  cors({
    origin: "*",
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

app.use((req, res, next) => {
  console.log("➡️ Incoming:", req.method, req.url);
  next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));

/* Static */
// const galleryDir = path.resolve("gallery");
const galleryDir = path.join(__dirname, "gallery");
const kundliDir = path.resolve("kundli");

// Serve static files on both base and /api prefix
app.use("/gallery", express.static(galleryDir));
app.use("/kundli", express.static(kundliDir));
app.use("/api/gallery", express.static(galleryDir));
app.use("/api/kundli", express.static(kundliDir));

// Debug 404s for gallery
app.use("/gallery", (req, res) => {
  console.log(`❌ Gallery File Not Found: ${path.join(galleryDir, req.url)}`);
  res.status(404).send("File not found in gallery");
});

app.get("/api/gallery-test", async (req, res) => {
  try {
    const fs = await import("fs");
    const files = fs.existsSync(galleryDir) ? fs.readdirSync(galleryDir).slice(0, 10) : "DIR MISSING";
    res.json({ 
      message: "Gallery route is accessible", 
      dir: galleryDir,
      files_sample: files 
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});


app.get("/api/db-debug", (req, res) => {
  db.query("DESCRIBE register", (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Serve static files on both base and /api prefix
// app.use("/gallery", express.static(galleryDir));
app.use("/kundli", express.static(kundliDir));
app.use("/api/gallery", express.static(galleryDir));
app.use("/api/kundli", express.static(kundliDir));

// Debug 404s for gallery
app.use("/gallery", (req, res) => {
  console.log(`❌ Gallery File Not Found: ${path.join(galleryDir, req.url)}`);
  res.status(404).send("File not found in gallery");
});

app.get("/api/gallery-test", async (req, res) => {
  try {
    const fs = await import("fs");
    const files = fs.existsSync(galleryDir) ? fs.readdirSync(galleryDir).slice(0, 10) : "DIR MISSING";
    res.json({ 
      message: "Gallery route is accessible", 
      dir: galleryDir,
      files_sample: files 
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});


app.get("/api/db-debug", (req, res) => {
  db.query("DESCRIBE register", (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

/* Routes */
app.use("/api/register", registerRoutes);
app.use("/api/payment", paymentRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/contact", contactRoutes);

app.use("/api/auth", authRoutes);
app.use("/api/auth", idSearchRoutes);
app.use("/api/auth", interestRoutes);
app.use("/api/auth/forgot-password", forgotPasswordRoutes);

app.use("/api", searchRoutes);
app.use("/api/admin", adminRoutes);



// Logic routes for gallery (upload/delete)
app.use("/api/gallery", galleryRoutes);

app.get("/", (req, res) => res.send("Matrimony API running..."));

/* Server + Socket */
const server = http.createServer(app);

const io = new IOServer(server, {
  cors: { origin: "*", methods: ["GET", "POST"] },
});

const onlineMap = new Map();

io.on("connection", (socket) => {
  console.log("socket connected", socket.id);

  socket.on("register", ({ matriid, email }) => {
    const key = (matriid || email)?.toLowerCase();
    if (key) {
      onlineMap.set(key, socket.id);
      socket.data.userKey = key;
    }
  });

  socket.on("disconnect", () => {
    if (socket.data.userKey) {
      onlineMap.delete(socket.data.userKey);
    }
    console.log("socket disconnected", socket.id);
  });
});

app.set("io", io);
app.set("onlineMap", onlineMap);

/* Start server */
server.listen(PORT, HOST, () => {
  console.log(`🚀 Server running on http://${HOST}:${PORT}`);
  console.log("SMTP_USER present:", !!process.env.SMTP_USER);
  console.log("SMTP_PASS present:", !!process.env.SMTP_PASS);
});
